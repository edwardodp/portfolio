"""In-memory cache of the latest quote per ticker, used by the market data service."""

from __future__ import annotations

from collections import OrderedDict
from dataclasses import dataclass
from typing import Callable, Optional


@dataclass(frozen=True)
class Quote:
    """Best bid and ask for one instrument, in integer price ticks."""

    bid: int
    ask: int


class QuoteCache:
    """Holds the latest quote for up to `capacity` tickers.

    When the cache is full, adding a new ticker evicts the least recently used one.
    Both get() and put() count as a use.
    """

    def __init__(self, capacity: int) -> None:
        if capacity < 1:
            raise ValueError("capacity must be at least 1")
        self.capacity = capacity
        self._entries: "OrderedDict[str, Quote]" = OrderedDict()  # least recently used first

    def get(self, ticker: str) -> Optional[Quote]:
        """The latest quote for `ticker`, or None if it isn't cached."""
        return self._entries.get(ticker)

    def put(self, ticker: str, quote: Quote) -> None:
        """Stores the latest quote for `ticker`, replacing any previous quote."""
        if len(self._entries) >= self.capacity:
            self._entries.popitem(last=False)  # evict the least recently used ticker
        self._entries[ticker] = quote

    def __len__(self) -> int:
        return len(self._entries)

    def __contains__(self, ticker: str) -> bool:
        return ticker in self._entries


class QuoteService:
    """Serves quotes from the cache, falling back to the upstream quote store on a miss."""

    def __init__(self, fetch_upstream: Callable[[str], Quote], capacity: int = 1000) -> None:
        self._fetch_upstream = fetch_upstream
        self._cache = QuoteCache(capacity)
        self.hits = 0
        self.misses = 0

    def quote(self, ticker: str) -> Quote:
        cached = self._cache.get(ticker)
        if cached is not None:
            self.hits += 1
            return cached
        self.misses += 1
        fresh = self._fetch_upstream(ticker)
        self._cache.put(ticker, fresh)
        return fresh

    def on_market_update(self, ticker: str, quote: Quote) -> None:
        """Called by the market data feed whenever a ticker's quote changes."""
        if ticker in self._cache:
            self._cache.put(ticker, quote)

    def hit_rate(self) -> float:
        total = self.hits + self.misses
        return self.hits / total if total else 0.0
