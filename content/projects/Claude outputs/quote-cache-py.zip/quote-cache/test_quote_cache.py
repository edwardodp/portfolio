import unittest

from quote_cache import Quote, QuoteCache, QuoteService


class QuoteCacheTest(unittest.TestCase):
    def test_returns_what_was_put(self):
        cache = QuoteCache(2)
        cache.put("AAPL", Quote(18725, 18727))
        self.assertEqual(cache.get("AAPL"), Quote(18725, 18727))

    def test_missing_ticker_returns_none(self):
        cache = QuoteCache(2)
        cache.put("AAPL", Quote(18725, 18727))
        self.assertIsNone(cache.get("MSFT"))

    def test_evicts_oldest_ticker_when_full(self):
        cache = QuoteCache(2)
        cache.put("AAPL", Quote(18725, 18727))
        cache.put("MSFT", Quote(41210, 41214))
        cache.put("NVDA", Quote(12133, 12135))
        self.assertIsNone(cache.get("AAPL"))
        self.assertIsNotNone(cache.get("MSFT"))
        self.assertIsNotNone(cache.get("NVDA"))
        self.assertEqual(len(cache), 2)

    def test_rejects_zero_capacity(self):
        with self.assertRaises(ValueError):
            QuoteCache(0)


class QuoteServiceTest(unittest.TestCase):
    def test_fetches_upstream_once_then_serves_from_cache(self):
        calls = []

        def fetch(ticker):
            calls.append(ticker)
            return Quote(100, 101)

        service = QuoteService(fetch, capacity=2)
        self.assertEqual(service.quote("AAPL"), Quote(100, 101))
        self.assertEqual(service.quote("AAPL"), Quote(100, 101))
        self.assertEqual(calls, ["AAPL"])
        self.assertEqual(service.hit_rate(), 0.5)


if __name__ == "__main__":
    unittest.main()
