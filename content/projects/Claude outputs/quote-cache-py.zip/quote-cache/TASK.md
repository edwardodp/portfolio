# Task

The market data team has reported two bugs. Fix them both.

**Bug 1.** "AAPL is requested every few milliseconds, but it keeps getting evicted from
the cache while tickers nobody has asked for in minutes stay cached. Our hit rate is far
lower than it should be."

**Bug 2.** "When the cache is full, a market update for a ticker that's already cached
kicks a different ticker out, so the cache shrinks every time the market is busy."

Run the tests with `python3 -m unittest -v`. You have 15 minutes. Use the AI assistant,
and talk through what you're doing.
