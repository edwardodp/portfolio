# quote-cache

An LRU cache of the latest quote per ticker, used by the market data service so that
hot tickers don't hit the upstream quote store.

```
include/quote_cache.hpp   the cache
src/quote_cache.cpp
tests/                    unit tests (tiny_test.hpp is a minimal GoogleTest-style harness)
```

## Build and test

```
make test                  # build and run all tests
make test FILTER=Evicts    # only tests whose name contains "Evicts"
make clean
```
