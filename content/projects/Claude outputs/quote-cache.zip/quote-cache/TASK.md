# Task

The market data team has reported two bugs in `QuoteCache`. Fix them both.

**Bug 1.** "Tickers we read constantly still get evicted. AAPL is read every few
milliseconds, but it's regularly dropped from the cache while tickers nobody has looked
at for minutes stay in."

**Bug 2.** "After a ticker's quote has been updated a few times, `size()` reports more
tickers than we've stored, and sometimes a ticker we've only just updated disappears
from the cache."

You have 15 minutes. Use the AI assistant, and talk through what you're doing.
