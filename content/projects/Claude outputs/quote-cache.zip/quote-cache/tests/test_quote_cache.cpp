#include <cstddef>

#include "quote_cache.hpp"
#include "tiny_test.hpp"

using namespace mds;

TEST(QuoteCache, ReturnsWhatWasPut) {
    QuoteCache cache(2);
    cache.put("AAPL", Quote{18725, 18727});

    const auto quote = cache.get("AAPL");
    ASSERT_TRUE(quote.has_value());
    EXPECT_EQ(*quote, (Quote{18725, 18727}));
}

TEST(QuoteCache, MissingTickerReturnsNothing) {
    QuoteCache cache(2);
    cache.put("AAPL", Quote{18725, 18727});

    EXPECT_FALSE(cache.get("MSFT").has_value());
}

TEST(QuoteCache, EvictsOldestTickerWhenFull) {
    QuoteCache cache(2);
    cache.put("AAPL", Quote{18725, 18727});
    cache.put("MSFT", Quote{41210, 41214});
    cache.put("NVDA", Quote{12133, 12135});

    EXPECT_FALSE(cache.get("AAPL").has_value());
    EXPECT_TRUE(cache.get("MSFT").has_value());
    EXPECT_TRUE(cache.get("NVDA").has_value());
    EXPECT_EQ(cache.size(), std::size_t{2});
}
