#pragma once

#include <cstddef>
#include <cstdint>
#include <list>
#include <optional>
#include <ostream>
#include <string>
#include <unordered_map>
#include <utility>

namespace mds {

// Best bid and ask for one instrument, in integer price ticks.
struct Quote {
    std::int64_t bid = 0;
    std::int64_t ask = 0;
};

inline bool operator==(const Quote& a, const Quote& b) { return a.bid == b.bid && a.ask == b.ask; }
inline std::ostream& operator<<(std::ostream& out, const Quote& q) {
    return out << "{bid=" << q.bid << ", ask=" << q.ask << "}";
}

// Holds the latest quote for up to `capacity` tickers. When it's full, adding a new
// ticker evicts the least recently used one. Both get() and put() count as a use.
class QuoteCache {
public:
    explicit QuoteCache(std::size_t capacity);

    // The latest quote for `ticker`, if it's cached.
    std::optional<Quote> get(const std::string& ticker);

    // Stores the latest quote for `ticker`, replacing any previous quote.
    void put(const std::string& ticker, const Quote& quote);

    // Number of tickers currently cached.
    std::size_t size() const;
    std::size_t capacity() const { return capacity_; }

private:
    using Entry = std::pair<std::string, Quote>;

    std::size_t capacity_;
    std::list<Entry> entries_;  // most recently used first
    std::unordered_map<std::string, std::list<Entry>::iterator> index_;
};

}  // namespace mds
