#include "quote_cache.hpp"

namespace mds {

QuoteCache::QuoteCache(std::size_t capacity) : capacity_(capacity) {}

std::optional<Quote> QuoteCache::get(const std::string& ticker) {
    auto it = index_.find(ticker);
    if (it == index_.end()) return std::nullopt;
    return it->second->second;
}

void QuoteCache::put(const std::string& ticker, const Quote& quote) {
    if (entries_.size() >= capacity_) {
        // Full: evict the least recently used ticker.
        index_.erase(entries_.back().first);
        entries_.pop_back();
    }
    entries_.emplace_front(ticker, quote);
    index_[ticker] = entries_.begin();
}

std::size_t QuoteCache::size() const { return entries_.size(); }

}  // namespace mds
