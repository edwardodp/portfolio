#include "positions/portfolio.hpp"

namespace positions {

bool Portfolio::is_valid(const Trade& trade) {
    if (trade.id.empty() || trade.ticker.empty()) return false;
    if (trade.quantity < 0) return false;
    if (trade.price.cents() <= 0) return false;
    return true;
}

bool Portfolio::has_seen(const std::string& trade_id) const {
    return seen_trade_ids_.count(trade_id) > 0;
}

bool Portfolio::apply(const Trade& trade) {
    if (has_seen(trade.id)) return true;  // redelivery of a trade we've already applied
    if (!is_valid(trade)) return false;

    return trade.side == Side::Buy ? apply_buy(trade) : apply_sell(trade);
}

bool Portfolio::apply_buy(const Trade& trade) {
    Position& pos = positions_[trade.ticker];
    pos.ticker = trade.ticker;

    // Quantity-weighted average of the existing cost and this fill, to the nearest cent.
    const std::int64_t new_quantity = pos.quantity + trade.quantity;
    const std::int64_t total_cost =
        pos.avg_cost.cents() * pos.quantity + trade.price.cents() * trade.quantity;
    pos.avg_cost = Money{total_cost / new_quantity};
    pos.quantity = new_quantity;
    return true;
}

bool Portfolio::apply_sell(const Trade& trade) {
    auto it = positions_.find(trade.ticker);
    if (it == positions_.end() || it->second.quantity < trade.quantity) {
        return false;  // long-only: can't sell more than we hold
    }

    Position& pos = it->second;
    pos.quantity -= trade.quantity;
    if (pos.quantity == 0) {
        positions_.erase(it);  // position closed
    }

    realised_pnl_ += (trade.price - pos.avg_cost) * trade.quantity;
    return true;
}

std::optional<Position> Portfolio::position(const std::string& ticker) {
    const Position& pos = positions_[ticker];
    if (pos.quantity == 0) return std::nullopt;
    return pos;
}

std::vector<Position> Portfolio::positions() const {
    std::vector<Position> open;
    open.reserve(positions_.size());
    for (const auto& entry : positions_) {
        open.push_back(entry.second);
    }
    return open;
}

}  // namespace positions
