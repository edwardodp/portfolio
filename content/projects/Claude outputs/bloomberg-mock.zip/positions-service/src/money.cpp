#include "positions/money.hpp"

#include <stdexcept>
#include <string>

namespace positions {

Money Money::parse(std::string_view text) {
    const std::string s(text);
    if (s.empty()) throw std::invalid_argument("empty amount");

    const auto dot = s.find('.');
    if (dot != std::string::npos && s.size() - dot - 1 > 2) {
        throw std::invalid_argument("more than two decimal places: " + s);
    }

    std::size_t consumed = 0;
    const double value = std::stod(s, &consumed);
    if (consumed != s.size()) throw std::invalid_argument("malformed amount: " + s);

    return Money{static_cast<std::int64_t>(value * 100)};
}

std::string Money::to_string() const {
    const std::int64_t magnitude = cents_ < 0 ? -cents_ : cents_;
    std::string out = cents_ < 0 ? "-" : "";
    out += std::to_string(magnitude / 100);
    out += '.';
    const std::int64_t fraction = magnitude % 100;
    if (fraction < 10) out += '0';
    out += std::to_string(fraction);
    return out;
}

}  // namespace positions
