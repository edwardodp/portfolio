#include "positions/report.hpp"

#include <algorithm>
#include <iomanip>
#include <sstream>

namespace positions {

Money market_value(const Position& position, const PriceBook& prices) {
    // No print yet today (e.g. a new listing): value it at cost.
    const Money price = prices.last_price(position.ticker).value_or(position.avg_cost);
    return price * position.quantity;
}

Money total_market_value(const std::vector<Position>& positions, const PriceBook& prices) {
    Money total;
    for (const Position& p : positions) total += market_value(p, prices);
    return total;
}

std::string render_report(std::vector<Position> positions, const PriceBook& prices) {
    std::sort(positions.begin(), positions.end(),
              [](const Position& a, const Position& b) { return a.quantity > b.quantity; });

    std::ostringstream out;
    out << std::left << std::setw(8) << "TICKER" << std::right << std::setw(10) << "QTY"
        << std::setw(12) << "AVG_COST" << std::setw(12) << "LAST" << std::setw(16)
        << "MKT_VALUE" << std::setw(16) << "UNREAL_PNL" << '\n';

    for (const Position& p : positions) {
        const auto last = prices.last_price(p.ticker);
        const Money value = market_value(p, prices);
        out << std::left << std::setw(8) << p.ticker << std::right << std::setw(10)
            << p.quantity << std::setw(12) << p.avg_cost.to_string() << std::setw(12)
            << (last ? last->to_string() : std::string("-")) << std::setw(16)
            << value.to_string() << std::setw(16) << (value - p.cost()).to_string() << '\n';
    }

    out << std::left << std::setw(42) << "TOTAL" << std::right << std::setw(16)
        << total_market_value(positions, prices).to_string() << '\n';
    return out.str();
}

std::vector<Position> top_positions(const std::vector<Position>& positions,
                                    const PriceBook& prices, std::size_t n) {
    std::vector<Position> sorted = positions;
    std::sort(sorted.begin(), sorted.end(), [&](const Position& a, const Position& b) {
        return market_value(a, prices) > market_value(b, prices);
    });
    if (sorted.size() > n) sorted.resize(n);
    return sorted;
}

}  // namespace positions
