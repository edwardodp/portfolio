#include "positions/price_book.hpp"

namespace positions {

void PriceBook::update(const std::string& ticker, Money last_price) {
    prices_[ticker] = last_price;
}

std::optional<Money> PriceBook::last_price(const std::string& ticker) const {
    auto it = prices_.find(ticker);
    if (it == prices_.end()) return std::nullopt;
    return it->second;
}

}  // namespace positions
