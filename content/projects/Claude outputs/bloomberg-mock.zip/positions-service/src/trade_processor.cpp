#include "positions/trade_processor.hpp"

namespace positions {

bool TradeProcessor::submit(const Trade& trade) {
    // Fast path: the feeds redeliver a lot, so skip the lock for trades we've already applied.
    if (portfolio_.has_seen(trade.id)) return true;

    std::lock_guard<std::mutex> lock(mutex_);
    const bool accepted = portfolio_.apply(trade);
    if (accepted) ++applied_;
    return accepted;
}

std::vector<Position> TradeProcessor::snapshot() const {
    return portfolio_.positions();
}

Money TradeProcessor::realised_pnl() const {
    std::lock_guard<std::mutex> lock(mutex_);
    return portfolio_.realised_pnl();
}

}  // namespace positions
