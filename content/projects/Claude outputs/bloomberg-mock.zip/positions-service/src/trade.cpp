#include "positions/trade.hpp"

#include <stdexcept>

namespace positions {

Side parse_side(const std::string& text) {
    if (text == "BUY") return Side::Buy;
    if (text == "SELL") return Side::Sell;
    throw std::invalid_argument("unknown side: " + text);
}

}  // namespace positions
