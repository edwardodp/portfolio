# positions-service

Tracks one trading book's positions and P&L from a stream of trade executions, and
produces the end-of-day positions report.

- Behaviour is defined in `SPEC.md`.
- Open work items are in `TICKETS.md`.

## Layout

```
include/positions/   public headers
src/                 library implementation
apps/replay.cpp      replays a CSV of trades and prints the report
apps/bench_top.cpp   rough timing for top_positions()
tests/               unit tests (tiny_test.hpp is a minimal GoogleTest-style harness)
data/                sample input
```

## Build and test

Needs a C++17 compiler and `make`.

```
make test                  # build and run all tests
make test FILTER=Money     # only tests whose name contains "Money"
make all                   # also builds build/replay and build/bench_top
./build/replay data/sample_trades.csv data/sample_prices.csv
make clean
```

Compiler flags can be overridden, e.g. `make clean && make test CXXFLAGS="-std=c++17 -g -O1"`.
`make` doesn't notice flag changes on its own, so run `make clean` first.
