# Practice round: AI-assisted codebase interview

50 minutes. You're not expected to finish. In one real Bloomberg report, two of four
tickets was enough to pass, so do fewer things properly rather than start everything.

## Before the clock starts

1. `git init && git add -A && git commit -qm start` so you can diff at the end.
2. `make test`: it should build and pass.
3. Open this folder in an AI tool that can read the repo. Cursor's chat or agent is the
   closest to HackerRank's assistant. Don't use the Claude chat that gave you this repo:
   it knows where the bugs are.
4. Start a 50-minute timer.

## Part 1: spec vs code (about 25 minutes)

1. Read `SPEC.md`. In a new `NOTES.md`, list anything ambiguous and the question you'd
   ask about it. If you'd ask the interviewer, ask in the Claude chat: it will answer as
   the interviewer would, and only about the spec and tickets.
2. Find where the code doesn't do what `SPEC.md` says. For each problem: a test that
   fails first, then the fix, then every test passing.

## Part 2: tickets (the rest of the time)

`TICKETS.md` has three. Pick your own order.

## Talking

If tomorrow is live, practise talking out loud as you go: what you're asking the AI and
why. If not, write one line per step in `NOTES.md`.

## When time's up

Stop, even mid-change, then send the Claude chat:

1. `git add -A && git diff --cached > mock.diff` (this includes new files)
2. your AI conversation, copied and pasted or exported
3. `NOTES.md`

It will review the diff and the conversation the way an interviewer would, then ask a
few follow-up questions about your fixes.
