#pragma once

// A minimal GoogleTest-style harness so the repo builds with no dependencies.
// Supports TEST, EXPECT_EQ/NE/TRUE/FALSE/THROW and ASSERT_EQ/TRUE.

#include <exception>
#include <functional>
#include <iostream>
#include <sstream>
#include <string>
#include <type_traits>
#include <utility>
#include <vector>

namespace tiny_test {

struct TestCase {
    std::string name;
    std::function<void()> body;
};

inline std::vector<TestCase>& registry() {
    static std::vector<TestCase> tests;
    return tests;
}

struct Registrar {
    Registrar(std::string name, std::function<void()> body) {
        registry().push_back({std::move(name), std::move(body)});
    }
};

struct AssertionFailure {};  // thrown by ASSERT_* to stop the current test

inline int& failures_in_current_test() {
    static int count = 0;
    return count;
}

template <typename T, typename = void>
struct is_printable : std::false_type {};
template <typename T>
struct is_printable<T, std::void_t<decltype(std::declval<std::ostream&>() << std::declval<const T&>())>>
    : std::true_type {};

template <typename T>
std::string show(const T& value) {
    if constexpr (is_printable<T>::value) {
        std::ostringstream out;
        out << value;
        return out.str();
    } else {
        return "<unprintable>";
    }
}

inline void report_failure(const char* file, int line, const std::string& message) {
    ++failures_in_current_test();
    std::cerr << file << ":" << line << ": Failure\n  " << message << "\n";
}

template <typename A, typename B>
bool check_eq(const A& actual, const B& expected, const char* actual_text,
              const char* expected_text, const char* file, int line) {
    if (actual == expected) return true;
    report_failure(file, line,
                   std::string("Expected: ") + actual_text + " == " + expected_text +
                       "\n    actual:   " + show(actual) + "\n    expected: " + show(expected));
    return false;
}

template <typename A, typename B>
bool check_ne(const A& a, const B& b, const char* a_text, const char* b_text, const char* file,
              int line) {
    if (a != b) return true;
    report_failure(file, line,
                   std::string("Expected: ") + a_text + " != " + b_text + "\n    both: " + show(a));
    return false;
}

inline int run_all(int argc, char** argv) {
    const std::string filter = argc > 1 ? argv[1] : "";
    int run = 0;
    int failed = 0;
    for (const TestCase& test : registry()) {
        if (!filter.empty() && test.name.find(filter) == std::string::npos) continue;
        ++run;
        failures_in_current_test() = 0;
        std::cout << "[ RUN      ] " << test.name << std::endl;
        try {
            test.body();
        } catch (const AssertionFailure&) {
        } catch (const std::exception& e) {
            report_failure(__FILE__, __LINE__, std::string("uncaught exception: ") + e.what());
        }
        if (failures_in_current_test() == 0) {
            std::cout << "[       OK ] " << test.name << std::endl;
        } else {
            ++failed;
            std::cout << "[  FAILED  ] " << test.name << std::endl;
        }
    }
    std::cout << "\n" << (run - failed) << "/" << run << " tests passed" << std::endl;
    return failed == 0 ? 0 : 1;
}

}  // namespace tiny_test

#define TINY_TEST_CONCAT_INNER(a, b) a##b
#define TINY_TEST_CONCAT(a, b) TINY_TEST_CONCAT_INNER(a, b)

#define TEST(suite, name)                                                                \
    static void suite##_##name##_body();                                                 \
    static ::tiny_test::Registrar TINY_TEST_CONCAT(tiny_test_registrar_, __LINE__)(      \
        #suite "." #name, &suite##_##name##_body);                                       \
    static void suite##_##name##_body()

#define EXPECT_EQ(actual, expected) \
    ::tiny_test::check_eq((actual), (expected), #actual, #expected, __FILE__, __LINE__)

#define EXPECT_NE(a, b) ::tiny_test::check_ne((a), (b), #a, #b, __FILE__, __LINE__)

#define EXPECT_TRUE(condition)                                                            \
    do {                                                                                  \
        if (!(condition))                                                                 \
            ::tiny_test::report_failure(__FILE__, __LINE__, "Expected true: " #condition); \
    } while (0)

#define EXPECT_FALSE(condition)                                                            \
    do {                                                                                   \
        if (condition)                                                                     \
            ::tiny_test::report_failure(__FILE__, __LINE__, "Expected false: " #condition); \
    } while (0)

#define ASSERT_TRUE(condition)                                                            \
    do {                                                                                  \
        if (!(condition)) {                                                               \
            ::tiny_test::report_failure(__FILE__, __LINE__, "Expected true: " #condition); \
            throw ::tiny_test::AssertionFailure{};                                        \
        }                                                                                 \
    } while (0)

#define ASSERT_EQ(actual, expected)                                                         \
    do {                                                                                    \
        if (!::tiny_test::check_eq((actual), (expected), #actual, #expected, __FILE__,      \
                                   __LINE__))                                               \
            throw ::tiny_test::AssertionFailure{};                                          \
    } while (0)

#define EXPECT_THROW(statement, exception_type)                                           \
    do {                                                                                  \
        bool tiny_test_caught = false;                                                    \
        try {                                                                             \
            statement;                                                                    \
        } catch (const exception_type&) {                                                 \
            tiny_test_caught = true;                                                      \
        } catch (...) {                                                                   \
        }                                                                                 \
        if (!tiny_test_caught)                                                            \
            ::tiny_test::report_failure(__FILE__, __LINE__,                               \
                                        "Expected " #statement " to throw " #exception_type); \
    } while (0)
