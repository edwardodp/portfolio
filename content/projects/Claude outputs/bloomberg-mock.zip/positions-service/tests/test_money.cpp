#include <stdexcept>
#include <string>

#include "positions/money.hpp"
#include "tiny_test.hpp"

using positions::Money;

TEST(Money, ParsesWholeAndDecimalAmounts) {
    EXPECT_EQ(Money::parse("12").cents(), 1200);
    EXPECT_EQ(Money::parse("10.50").cents(), 1050);
    EXPECT_EQ(Money::parse("187.25").cents(), 18725);
}

TEST(Money, RejectsMalformedAmounts) {
    EXPECT_THROW(Money::parse(""), std::invalid_argument);
    EXPECT_THROW(Money::parse("abc"), std::invalid_argument);
    EXPECT_THROW(Money::parse("12x"), std::invalid_argument);
    EXPECT_THROW(Money::parse("1.234"), std::invalid_argument);
}

TEST(Money, FormatsWithTwoDecimalPlaces) {
    EXPECT_EQ(Money{1050}.to_string(), std::string("10.50"));
    EXPECT_EQ(Money{5}.to_string(), std::string("0.05"));
    EXPECT_EQ(Money{-307}.to_string(), std::string("-3.07"));
}
