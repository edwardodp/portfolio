#include <cstddef>

#include "positions/trade_processor.hpp"
#include "tiny_test.hpp"

using namespace positions;

TEST(TradeProcessor, AppliesSubmittedTrades) {
    TradeProcessor processor;
    EXPECT_TRUE(processor.submit(Trade{"E1", "AAPL", Side::Buy, 10, Money::parse("150.00")}));
    EXPECT_TRUE(processor.submit(Trade{"E2", "AAPL", Side::Sell, 4, Money::parse("155.00")}));

    const auto snapshot = processor.snapshot();
    ASSERT_EQ(snapshot.size(), std::size_t{1});
    EXPECT_EQ(snapshot[0].quantity, 6);
    EXPECT_EQ(processor.realised_pnl(), Money::parse("20.00"));
    EXPECT_EQ(processor.applied_count(), std::size_t{2});
}
