#include <cstddef>
#include <string>
#include <vector>

#include "positions/report.hpp"
#include "tiny_test.hpp"

using namespace positions;

TEST(Report, MarketValueUsesLastPrice) {
    PriceBook prices;
    prices.update("AAPL", Money::parse("160.00"));
    const Position aapl{"AAPL", 10, Money::parse("150.00")};

    EXPECT_EQ(market_value(aapl, prices), Money::parse("1600.00"));
}

TEST(Report, TopPositionsOrdersByMarketValue) {
    PriceBook prices;
    prices.update("A", Money::parse("1.00"));
    prices.update("B", Money::parse("5.00"));
    prices.update("C", Money::parse("2.00"));
    const std::vector<Position> book = {{"A", 100, Money::parse("1.00")},   // 100.00
                                        {"B", 10, Money::parse("5.00")},    //  50.00
                                        {"C", 40, Money::parse("2.00")}};   //  80.00

    const auto top = top_positions(book, prices, 2);
    ASSERT_EQ(top.size(), std::size_t{2});
    EXPECT_EQ(top[0].ticker, std::string("A"));
    EXPECT_EQ(top[1].ticker, std::string("C"));
}

TEST(Report, RendersEachPosition) {
    PriceBook prices;
    prices.update("AAPL", Money::parse("160.00"));
    const std::vector<Position> book = {{"AAPL", 10, Money::parse("150.00")}};

    const std::string report = render_report(book, prices);
    EXPECT_TRUE(report.find("AAPL") != std::string::npos);
    EXPECT_TRUE(report.find("1600.00") != std::string::npos);
}
