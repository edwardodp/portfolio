#include <cstddef>
#include <cstdint>
#include <string>
#include <utility>

#include "positions/portfolio.hpp"
#include "tiny_test.hpp"

using namespace positions;

namespace {

Trade buy(std::string id, std::string ticker, std::int64_t quantity, const char* price) {
    return Trade{std::move(id), std::move(ticker), Side::Buy, quantity, Money::parse(price)};
}

Trade sell(std::string id, std::string ticker, std::int64_t quantity, const char* price) {
    return Trade{std::move(id), std::move(ticker), Side::Sell, quantity, Money::parse(price)};
}

}  // namespace

TEST(Portfolio, BuyOpensPosition) {
    Portfolio book;
    EXPECT_TRUE(book.apply(buy("E1", "AAPL", 100, "150.00")));

    const auto pos = book.position("AAPL");
    ASSERT_TRUE(pos.has_value());
    EXPECT_EQ(pos->quantity, 100);
    EXPECT_EQ(pos->avg_cost, Money::parse("150.00"));
}

TEST(Portfolio, BuysAverageTheCost) {
    Portfolio book;
    book.apply(buy("E1", "MSFT", 100, "300.00"));
    book.apply(buy("E2", "MSFT", 100, "310.00"));

    const auto pos = book.position("MSFT");
    ASSERT_TRUE(pos.has_value());
    EXPECT_EQ(pos->quantity, 200);
    EXPECT_EQ(pos->avg_cost, Money::parse("305.00"));
}

TEST(Portfolio, PartialSellRealisesPnl) {
    Portfolio book;
    book.apply(buy("E1", "IBM", 100, "200.00"));
    EXPECT_TRUE(book.apply(sell("E2", "IBM", 40, "210.00")));

    const auto pos = book.position("IBM");
    ASSERT_TRUE(pos.has_value());
    EXPECT_EQ(pos->quantity, 60);
    EXPECT_EQ(pos->avg_cost, Money::parse("200.00"));
    EXPECT_EQ(book.realised_pnl(), Money::parse("400.00"));
}

TEST(Portfolio, SellingEverythingClosesThePosition) {
    Portfolio book;
    book.apply(buy("E1", "TSLA", 10, "250.00"));
    EXPECT_TRUE(book.apply(sell("E2", "TSLA", 10, "260.00")));

    EXPECT_FALSE(book.position("TSLA").has_value());
}

TEST(Portfolio, CannotSellMoreThanHeld) {
    Portfolio book;
    book.apply(buy("E1", "NVDA", 10, "120.00"));
    EXPECT_FALSE(book.apply(sell("E2", "NVDA", 11, "125.00")));

    const auto pos = book.position("NVDA");
    ASSERT_TRUE(pos.has_value());
    EXPECT_EQ(pos->quantity, 10);
}

TEST(Portfolio, ListsOpenPositions) {
    Portfolio book;
    book.apply(buy("E1", "AAPL", 10, "150.00"));
    book.apply(buy("E2", "MSFT", 5, "300.00"));

    EXPECT_EQ(book.positions().size(), std::size_t{2});
}
