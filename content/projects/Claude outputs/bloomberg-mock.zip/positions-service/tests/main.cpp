#include "tiny_test.hpp"

// Usage: run_tests [NAME_FILTER]   runs tests whose "Suite.Name" contains NAME_FILTER
int main(int argc, char** argv) { return tiny_test::run_all(argc, argv); }
