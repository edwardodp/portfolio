// Replays a CSV of executions through a Portfolio and prints the end-of-day report.
//
//   usage: replay TRADES.csv PRICES.csv
//
// TRADES.csv columns: id,ticker,side,quantity,price
// PRICES.csv columns: ticker,price

#include <exception>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include <vector>

#include "positions/portfolio.hpp"
#include "positions/price_book.hpp"
#include "positions/report.hpp"

namespace {

std::vector<std::string> split_csv_line(const std::string& line) {
    std::vector<std::string> fields;
    std::stringstream in(line);
    std::string field;
    while (std::getline(in, field, ',')) fields.push_back(field);
    return fields;
}

// Calls fn(fields, line_number) for each data row, skipping the header row.
template <typename Fn>
bool for_each_row(const char* path, Fn fn) {
    std::ifstream in(path);
    if (!in) {
        std::cerr << "cannot open " << path << "\n";
        return false;
    }
    std::string line;
    int line_number = 0;
    while (std::getline(in, line)) {
        ++line_number;
        if (line_number == 1 || line.empty()) continue;
        fn(split_csv_line(line), line_number);
    }
    return true;
}

}  // namespace

int main(int argc, char** argv) {
    using namespace positions;

    if (argc != 3) {
        std::cerr << "usage: " << argv[0] << " TRADES.csv PRICES.csv\n";
        return 2;
    }
    const char* trades_path = argv[1];
    const char* prices_path = argv[2];

    Portfolio book;
    int rejected = 0;
    bool ok = for_each_row(trades_path, [&](const std::vector<std::string>& f, int line) {
        if (f.size() != 5) {
            std::cerr << trades_path << ":" << line << ": expected 5 fields\n";
            ++rejected;
            return;
        }
        try {
            const Trade trade{f[0], f[1], parse_side(f[2]), std::stoll(f[3]), Money::parse(f[4])};
            if (!book.apply(trade)) {
                std::cerr << trades_path << ":" << line << ": rejected trade " << trade.id << "\n";
                ++rejected;
            }
        } catch (const std::exception& e) {
            std::cerr << trades_path << ":" << line << ": " << e.what() << "\n";
            ++rejected;
        }
    });

    PriceBook prices;
    ok = for_each_row(prices_path, [&](const std::vector<std::string>& f, int line) {
        try {
            if (f.size() != 2) throw std::invalid_argument("expected 2 fields");
            prices.update(f[0], Money::parse(f[1]));
        } catch (const std::exception& e) {
            std::cerr << prices_path << ":" << line << ": " << e.what() << "\n";
        }
    }) && ok;
    if (!ok) return 1;

    std::cout << render_report(book.positions(), prices);
    std::cout << "\nRealised P&L:  " << book.realised_pnl() << "\n";
    std::cout << "Rejected rows: " << rejected << "\n";
    return 0;
}
