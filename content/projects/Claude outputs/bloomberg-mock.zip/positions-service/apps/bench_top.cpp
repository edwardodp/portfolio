// Rough timing for top_positions() on a large book (TICKETS.md, POS-103).

#include <chrono>
#include <cstdint>
#include <cstdio>
#include <random>
#include <string>
#include <vector>

#include "positions/price_book.hpp"
#include "positions/report.hpp"

int main() {
    using namespace positions;

    constexpr std::size_t kPositions = 200'000;
    constexpr std::size_t kTop = 10;
    constexpr int kCalls = 20;

    std::mt19937_64 rng(42);
    std::uniform_int_distribution<std::int64_t> quantity(1, 50'000);
    std::uniform_int_distribution<std::int64_t> cents(100, 500'000);

    std::vector<Position> book;
    book.reserve(kPositions);
    PriceBook prices;
    for (std::size_t i = 0; i < kPositions; ++i) {
        const std::string ticker = "T" + std::to_string(i);
        book.push_back(Position{ticker, quantity(rng), Money{cents(rng)}});
        prices.update(ticker, Money{cents(rng)});
    }

    std::int64_t checksum = 0;
    const auto start = std::chrono::steady_clock::now();
    for (int i = 0; i < kCalls; ++i) {
        const auto top = top_positions(book, prices, kTop);
        checksum += top.front().quantity;
    }
    const auto elapsed = std::chrono::steady_clock::now() - start;
    const double ms_per_call = std::chrono::duration<double, std::milli>(elapsed).count() / kCalls;

    std::printf("top_positions(n=%zu) over %zu positions: %.2f ms per call (checksum %lld)\n",
                kTop, kPositions, ms_per_call, static_cast<long long>(checksum));
    return 0;
}
