# Tickets

## POS-101: Crashes and over-counting under load

Each exchange feed handler runs on its own thread and calls `TradeProcessor::submit()`.
The reporting thread calls `snapshot()` and `realised_pnl()` once a second.

In production we see occasional crashes inside `snapshot()`, and `applied_count()`
sometimes ends up larger than the number of distinct trades we received.

Find the cause, fix it, and add a test that would have caught it.

## POS-102: Stock splits

The corporate actions team needs us to process forward stock splits.

Add `Portfolio::apply_split(const std::string& ticker, std::int64_t ratio)` for an
N-for-1 split: every share becomes `ratio` shares (`ratio` is at least 2). The open
position's quantity is multiplied by `ratio` and its average cost is divided by `ratio`,
so the position's cost is unchanged. A split for a ticker with no open position does
nothing. Reverse splits are out of scope.

## POS-103: top_positions() is too slow

The risk dashboard calls `top_positions(positions, prices, 10)` several times a second
on books with up to 200,000 open positions, and it's now the hottest function in the
profile. Make it faster for small `n` without changing its results.

`make all && ./build/bench_top` gives a rough timing.
