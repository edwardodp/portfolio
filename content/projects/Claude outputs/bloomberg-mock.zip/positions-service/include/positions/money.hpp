#pragma once

#include <cstdint>
#include <ostream>
#include <string>
#include <string_view>

namespace positions {

// An exact amount of money in whole cents. All prices, costs and P&L use this type.
class Money {
public:
    constexpr Money() = default;
    constexpr explicit Money(std::int64_t cents) : cents_(cents) {}

    // Parses a decimal amount with at most two decimal places, e.g. "187.25",
    // "42" or "-3.5". Throws std::invalid_argument on malformed input.
    static Money parse(std::string_view text);

    constexpr std::int64_t cents() const { return cents_; }

    // Two decimal places, e.g. "1600.00" or "-3.07".
    std::string to_string() const;

    constexpr Money& operator+=(Money other) {
        cents_ += other.cents_;
        return *this;
    }
    constexpr Money& operator-=(Money other) {
        cents_ -= other.cents_;
        return *this;
    }

    friend constexpr Money operator+(Money a, Money b) { return Money{a.cents_ + b.cents_}; }
    friend constexpr Money operator-(Money a, Money b) { return Money{a.cents_ - b.cents_}; }
    friend constexpr Money operator*(Money a, std::int64_t n) { return Money{a.cents_ * n}; }

    friend constexpr bool operator==(Money a, Money b) { return a.cents_ == b.cents_; }
    friend constexpr bool operator!=(Money a, Money b) { return a.cents_ != b.cents_; }
    friend constexpr bool operator<(Money a, Money b) { return a.cents_ < b.cents_; }
    friend constexpr bool operator>(Money a, Money b) { return a.cents_ > b.cents_; }

private:
    std::int64_t cents_ = 0;
};

inline std::ostream& operator<<(std::ostream& out, Money m) { return out << m.to_string(); }

}  // namespace positions
