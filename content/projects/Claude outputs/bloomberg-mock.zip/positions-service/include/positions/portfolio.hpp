#pragma once

#include <map>
#include <optional>
#include <string>
#include <unordered_set>
#include <vector>

#include "positions/money.hpp"
#include "positions/position.hpp"
#include "positions/trade.hpp"

namespace positions {

// Positions and realised P&L for one book. Not thread-safe: see TradeProcessor.
class Portfolio {
public:
    // Applies one execution (SPEC.md rules 2-7). Returns false if the trade is
    // rejected, in which case nothing changes.
    bool apply(const Trade& trade);

    // True if a trade with this id has already been applied.
    bool has_seen(const std::string& trade_id) const;

    // The open position in `ticker`, if there is one.
    std::optional<Position> position(const std::string& ticker);

    // Every open position, ordered by ticker.
    std::vector<Position> positions() const;

    Money realised_pnl() const { return realised_pnl_; }

private:
    static bool is_valid(const Trade& trade);
    bool apply_buy(const Trade& trade);
    bool apply_sell(const Trade& trade);

    std::map<std::string, Position> positions_;
    std::unordered_set<std::string> seen_trade_ids_;
    Money realised_pnl_;
};

}  // namespace positions
