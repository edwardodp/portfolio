#pragma once

#include <atomic>
#include <cstddef>
#include <mutex>
#include <vector>

#include "positions/money.hpp"
#include "positions/portfolio.hpp"
#include "positions/position.hpp"
#include "positions/trade.hpp"

namespace positions {

// Thread-safe front end to a Portfolio. Each exchange feed handler calls submit()
// from its own thread; the reporting thread calls snapshot() and realised_pnl().
class TradeProcessor {
public:
    // Returns false if the trade was rejected.
    bool submit(const Trade& trade);

    std::vector<Position> snapshot() const;
    Money realised_pnl() const;

    // Number of trades applied so far.
    std::size_t applied_count() const { return applied_.load(); }

private:
    mutable std::mutex mutex_;
    Portfolio portfolio_;
    std::atomic<std::size_t> applied_{0};
};

}  // namespace positions
