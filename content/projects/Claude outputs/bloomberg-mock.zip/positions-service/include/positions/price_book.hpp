#pragma once

#include <cstddef>
#include <optional>
#include <string>
#include <unordered_map>

#include "positions/money.hpp"

namespace positions {

// Last traded price for each ticker.
class PriceBook {
public:
    void update(const std::string& ticker, Money last_price);

    std::optional<Money> last_price(const std::string& ticker) const;

    std::size_t size() const { return prices_.size(); }

private:
    std::unordered_map<std::string, Money> prices_;
};

}  // namespace positions
