#pragma once

#include <cstdint>
#include <string>

#include "positions/money.hpp"

namespace positions {

struct Position {
    std::string ticker;
    std::int64_t quantity = 0;
    Money avg_cost;  // average cost per share

    Money cost() const { return avg_cost * quantity; }
};

}  // namespace positions
