#pragma once

#include <cstdint>
#include <string>

#include "positions/money.hpp"

namespace positions {

enum class Side { Buy, Sell };

// One execution from the exchange feed. See SPEC.md for the rules.
struct Trade {
    std::string id;
    std::string ticker;
    Side side = Side::Buy;
    std::int64_t quantity = 0;
    Money price;  // per share
};

// Parses "BUY" or "SELL". Throws std::invalid_argument for anything else.
Side parse_side(const std::string& text);

}  // namespace positions
