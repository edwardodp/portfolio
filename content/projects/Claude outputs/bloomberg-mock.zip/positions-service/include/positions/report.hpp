#pragma once

#include <cstddef>
#include <string>
#include <vector>

#include "positions/money.hpp"
#include "positions/position.hpp"
#include "positions/price_book.hpp"

namespace positions {

// Value of one position at its ticker's last price (SPEC.md rule 10).
Money market_value(const Position& position, const PriceBook& prices);

// Sum of market_value() over all positions.
Money total_market_value(const std::vector<Position>& positions, const PriceBook& prices);

// End-of-day report (SPEC.md rule 11): a header, one line per position, and a total.
std::string render_report(std::vector<Position> positions, const PriceBook& prices);

// The n positions with the largest market value, largest first.
std::vector<Position> top_positions(const std::vector<Position>& positions,
                                    const PriceBook& prices, std::size_t n);

}  // namespace positions
