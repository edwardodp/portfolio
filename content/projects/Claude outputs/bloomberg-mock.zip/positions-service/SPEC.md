# Positions service: behaviour spec

## Trades

Each trade execution has:

| field      | meaning                                                                 |
|------------|-------------------------------------------------------------------------|
| `id`       | identifier assigned by the exchange, unique per execution              |
| `ticker`   | instrument symbol, e.g. `AAPL`                                         |
| `side`     | `BUY` or `SELL`                                                        |
| `quantity` | number of shares, a positive integer                                   |
| `price`    | price per share, a decimal string with at most two decimal places, e.g. `187.25` |

## Money

1. All money (prices, costs and P&L) is held as an exact whole number of cents. Prices
   are converted from their decimal string exactly. No floating point is used.

## Applying trades

2. A trade whose quantity or price is not positive, or whose id or ticker is empty, is
   rejected: `apply` returns `false` and nothing changes.
3. The trade feed can deliver the same execution more than once. A trade whose id has
   already been applied is ignored, and must not change any position or P&L.
4. The book is long-only. A SELL for more shares than are currently held is rejected.
5. A BUY increases the position's quantity. The position's average cost becomes the
   quantity-weighted average of its previous average cost and the trade price, rounded
   to the nearest cent.
6. A SELL decreases the quantity and leaves the average cost unchanged. It realises
   P&L of `quantity × (sell price − average cost)`, which is added to the book's
   realised P&L.
7. When a position's quantity reaches zero it is closed: it no longer appears among the
   open positions, and a later BUY in the same ticker starts a fresh position.

## Queries

8. `position(ticker)` returns the open position in `ticker`, or nothing if there is none.
9. `positions()` returns every open position.
10. The market value of a position is its quantity multiplied by the ticker's last price.

## Report

11. The end-of-day report lists every open position, sorted by size, largest first, with
    its quantity, average cost, last price, market value and unrealised P&L (market
    value minus cost).
